<?php 
session_start();
$_GET['e'] = empty($_GET['e'])?'':$_GET['e'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./img/books.jpg" type="image/x-icon">
    <link rel="stylesheet" href="./css/index.css">
    <style>
        #links{display: flex; justify-content: space-between;width: 90%;margin-bottom: 10px;}
        span {color: rgba(43, 198, 43, 0.952);font-weight: 700;}
    </style>
    <title>sd>login</title>
</head>
<body>
<div id="content">
    <div id="about" class="index">
        <h2><img src="./img/books.jpg" alt=""></h2>
        <p>Projecto da cadeira de Sistemas Distribuídos, ministrada pela <b>MSc Martina de Barros</b>, na Faculdade de Engenharias e Tecnologias de Universidade Pedagógica de Maputo.        
        <br/><br/>
        <ul>
            <b style="color: blue; font-size: 1.2em">Operações:</b>
            <br/>
            <li>Inserir recurso</li>
            <li>Consultar recurso</li>
            <li>Requisitar/reservar um recurso</li>
            <li>Devolver um recurso</li>
            <li>Listar recursos</li>
        </ul>	
        <br>
        <span>Arlindo Maibasse & Henrique Macitela</span>
        </p>
    </div>

    <div id="form" class="index">
        <h2>Login</h2>
        <div class="erro"><?php echo $_GET['e']; ?></div>
        <form action="./php/autenticar.php" method="post" id="form-login">
            <div class="input-grup">
                <input type="email" name="email" id="email" required>
                <label for="email">Email</label>
            </div>
            <div class="input-grup">
                <input type="password" name="senha" id="senha" required>
                <label for="senha">Password</label>
            </div>
            <div id="links">
                <a href="./views/recuperarSenha.php">Esquceu a password</a>
                <a href="./views/cadastro.php">Cadastra-se</a>
            </div>
            <button type="submit" name="btn">Login</button>
            
        </form>    
    </div>
</div>    
</body>
</html>