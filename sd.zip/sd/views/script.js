setTimeout(()=>{
  window.location.reload()  
},60000)


