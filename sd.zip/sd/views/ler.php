<?php
session_start();
require_once'../php/_db.php';
if(!isset($_SESSION['id'])){    
    header('Location: ../index.php');
    die();   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/books.jpg" type="image/x-icon">
    <link rel="stylesheet" href="../css/home.css">
    <link rel="stylesheet" href="../css/section.css">
    <title>my Books</title>
</head>
<body> 
<div id="content">
    <header>
        <div><img src="../img/books.jpg" alt="logo" id="ll"></div>
        <h2>SD<i>Livraria</i></h2>
        <div></div>
    </header>
    <main>
        <aside>
            <div id="info">
                <?php
                    $foto = "../perfil/".$_SESSION['foto'];
                    echo"<img src='$foto'>";
                ?> 
                <h3><?php echo $_SESSION['nome']; ?></h3>
                <p><?php echo $_SESSION['email']; ?></p>
            </div>

            <div id="accao">
                <a href="./inserir.php">Inserir</a>
                <a href="./consultar.php">Consultar</a>
                <a href="./listar.php">Listar</a>
                <a class="active" href="./meus.php">My books</a>
                <a href="./chat.php">Chat</a>
            </div>
            <a href="../php/logout.php" id="bt-sair">
                <img src="../img/sair.svg" alt="sair">
            </a> 
        </aside>
        <section id="">            
            <a href="./meus.php" id="cancelar" >X</a>
            <div id="mybooks" style="display: flex;justify-content: center;align-items: center;">
                <?php
                $book = $_GET['l'];
                echo"
                    <embed src='../recurso/$book' type='application/pdf' style='width: 300%; height: 500px'>
                ";                
                ?>                
            </div>
        </section>
    </main>
</div>
</body>
</html>