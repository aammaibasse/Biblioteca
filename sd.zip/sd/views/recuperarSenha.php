
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/books.jpg" type="image/x-icon">
    <link rel="stylesheet" href="../css/index.css">
    <title>sd>login</title>
</head>
<body>
<div id="content">
    <div id="about" class="index">
        <h2><img src="../img/books.jpg" alt=""></h2>
        <p>Esquceu a password?<br><b>Nao tem problema</b>        
        <br/><br/>
        <p>Ajudamos voce a recuperar a senha <br/>Siga os passos!!!</p>	
        </p>
    </div>

    <div id="form" class="index">
        <h2>Recuperar a Senha</h2>
        <form method="post" id="form-login">
            <div class="input-grup">
                <input type="email" name="email" id="email" required>
                <label for="email">Digita o seu Email</label>
            </div>
            <button type="submit" name="btn">Enviar</button>

            <a href="../index.php">Fazer Login</a>
        </form>
        
    </div>
</div>    
</body>
</html>


<!-- Enviar o email -->
<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

if(isset($_POST['btn'])){

    $nome = 'SD Livraria';
    $email = addslashes($_POST['email']);
    $assunto = 'Recuprar senha';
    $messagem = 'Codigo eh &&&';

    
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';


    $mail = new PHPMailer();


    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = 'true';                                   //Enable SMTP authentication
    $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
    $mail->Port       = '587';   
               
    $mail->Username   = 'arlindoalipio@gmail.com';                     //SMTP username
    $mail->Password   = '8451arlindo66295';                               //SMTP password
    $mail->Subject = 'Recuparar a senha';
    $mail->Body    = 'Recebido o pedido de recuparar a senha! <br/>codigo: <b>12345</b>';
    $mail->AltBody = 'Texto alternativo';
 
    $mail->setFrom('arlindoalipio@gmail.com');
    $mail->addAddress('arlindoalipio@gmail.com');               //Name is optional



        if($mail->send()){
            echo 'Message has been sent';
        }else{
            echo 'Erro no envio do email';
        }





}