<?php
session_start();
require_once'../php/_db.php';
if(!isset($_SESSION['id'])){    
    header('Location: ../index.php');
    die();   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/books.jpg" type="image/x-icon">
    <link rel="stylesheet" href="../css/home.css">
    <link rel="stylesheet" href="../css/section.css">
    <title>ver recursos</title>
</head>
<body> 
<div id="content">
    <header>
        <div><img src="../img/books.jpg" alt="logo" id="ll"></div>
        <h2>SD<i>Livraria</i></h2>
        <div></div>
    </header>
    <main>
        <aside>
            <div id="info">
                <?php
                    $foto = "../perfil/".$_SESSION['foto'];
                    echo"<img src='$foto'>";
                ?> 
                <h3><?php echo $_SESSION['nome']; ?></h3>
                <p><?php echo $_SESSION['email']; ?></p>
            </div>

            <div id="accao">
                <a href="./inserir.php">Inserir</a>
                <a href="./consultar.php">Consultar</a>
                <a class="active" href="./listar.php">Listar</a>
                <a href="./meus.php">My books</a>
                <a href="./chat.php">Chat</a>
            </div>
            <a href="../php/logout.php" id="bt-sair">
                <img src="../img/sair.svg" alt="sair">
            </a> 
        </aside>

        <section id="livros">            
            <a href="./home.php" id="cancelar" >X</a>
            <div id="listar">

            <?php
                    $sql = "SELECT * FROM recurso"; 
                    $sql = $con->query($sql);
                    while($r = $sql->fetch_assoc()){ 
                        $book = $r['livro'];
                        $capa = $r['capa'];
                        
                        echo"
                            <div id='livro' >
                                <div id='img'>
                                <img  src='../recurso/capa/$capa' alt='' style='flex: 2; width:105%; height: 120px;'>
                                <div style='flex: 3; margin-left: 7px;'>
                                    <p>
                                        <b>".$r['titulo']." </b><br/>
                                        </b>Autor: </b> ".$r['autor']."<br/>
                                        <b>Língua: </b> ".$r['lingua']."<br/>
                                        <b>Ano: </b> ".$r['ano']."<br/>
                                        ";

                                        if($r['estado'] == 'Disponível'){
                                            echo "<b style='color:green;'>".$r['estado']."</b>";
                                        }else{
                                            echo "<b style='color:red;'>".$r['estado']."</b>";
                                        }
                                        echo"                                        
                                    </p>
                                </div>
                            </div>
                            <div id='links'>";

                            if($r['estado'] == 'Disponível'){
                                echo"<a href='../php/requisitar.php?l=".$r['id']."'>Requisitar</a>";
                            }else{
                                if($r['reserva'] == '0'){
                                    echo"<a href='../php/reservar.php?l=".$r['id']."'>Reservar</a>";   
                                }
                            }
                            $_SESSION['obra'] = $r['titulo'];
                            echo"                                
                                <a href='./comentarios.php?l=".$r['id']."'>Comentários</a>
                            </div>
                            </div>
                        ";                             
                    }
                ?>  
            </div> 
        </section>
    </main>
</div>
<script>setTimeout(()=>{window.location.reload()},5000)</script>
</body>
</html>