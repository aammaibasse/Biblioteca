<?php 
session_start();
$_GET['e'] = empty($_GET['e'])?'':$_GET['e'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/books.jpg" type="image/x-icon">
    <link rel="stylesheet" href="../css/index.css">
    <title>sd/cadastrar</title>
</head>
<body>
<div id="content">
    <div id="form" class="index">
        <h2>Cadastro</h2>
        <div class="erro"><?php echo $_GET['e']; ?></div>
        <form action="../php/cadastrar.php" method="post" id="form-cad" enctype="multipart/form-data">
            <div class="input-grup">
                <input type="text" name="nome" id="nome" required>
                <label for="nome">Nome</label>
            </div>

            <div class="input-grup file">
                <input type="file" name="foto" id="foto" style="border: none;">
            </div>   
                           
            <div class="input-grup">
                <input type="email" name="email" id="email" required>
                <label for="email">e-mail</label>
            </div>
            <div class="input-grup">
                <input type="password" name="senha" id="senha" required>
                <label for="senha">Criar Senha</label>
            </div>
            <div class="input-grup">
                <input type="password" name="csenha" id="csenha" required>
                <label for="csenha">Confirmar Senha</label>
            </div>
                
            <button name="btn" type="submit">Cadastrar</button>            
            <a href="../index.php">Fazer Login</a>
        </form>        
    </div>
    <div id="about" class="index">
        <h2><img src="../img/books.jpg" alt=""></h2>
        <p>Projecto da cadeira de Sistemas Distribuídos, ministrada pela <b>MSc Martina de Barros</b>, na Faculdade de Engenharias e Tecnologias de Universidade Pedagógica de Maputo.        
        <br/><br/>
        <ul>
            <b style="color: var(--titulo); font-size: 1.2em">Operações:</b>
            <br/>
            <li>Inserir recurso</li>
            <li>Consultar recurso</li>
            <li>Requisitar/reservar um recurso</li>
            <li>Devolver um recurso</li>
            <li>Listar recursos</li>
           </ul>	
        </p>
    </div>
</div>
</body>
</html>