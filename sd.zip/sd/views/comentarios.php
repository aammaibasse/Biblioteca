<?php
session_start();
require_once'../php/_db.php';
if(!isset($_SESSION['id'])){    
    header('Location: ../index.php');
    die();   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/books.jpg" type="image/x-icon">
    <link rel="stylesheet" href="../css/home.css">
    <link rel="stylesheet" href="../css/chat.css">
    <style> #cancelar{  top: 60px; left: 155px;  }
        @media screen and (max-width:600px) {
            main{
                flex-direction: column;
            }

            aside{
                justify-content: space-between;
                width: 100%;
                padding: 0px 5px;
                height: fit-content;
                border-radius: 0px;
                display: flex;
                flex-direction: row;
                align-items: center;
            }
        } 
    </style>
    <title>comentarios</title>

</head>
<body> 
<div id="content">
    <header>
        <div><img src="../img/books.jpg" alt="logo" id="ll"></div>
        <h2>SD<i>Livraria</i></h2>
        <div></div>
    </header>
    <main>
        <aside>              
            <div id="info">
                <?php
                    $foto = "../perfil/".$_SESSION['foto'];
                    echo"<img src='$foto'>";
                ?> 
                <h3><?php echo $_SESSION['nome']; ?></h3>
                <p><?php echo $_SESSION['email']; ?></p>
            </div>

            <div id="accao">
                <a href="./inserir.php">Inserir</a>
                <a href="./consultar.php">Consultar</a>
                <a href="./listar.php">Listar</a>
                <a href="./meus.php">My books</a>
                <a href="./chat.php">Chat</a>
            </div>
            <a href="../php/logout.php" id="bt-sair">
                <img src="../img/sair.svg" alt="sair">
            </a> 
            <a href="./home.php" id="cancelar">X </a>  
        </aside>
        <section>
       
        <span id="obra">            
            <?php
                $obra = $_GET['l'];         
                $sql = "SELECT * FROM recurso WHERE id = '$obra'";
                $res = $con->query($sql);
                if($res->num_rows > 0){
                    $res = $res->fetch_assoc();
                    echo $res['titulo']."<div style='color:white;margin-left:3px;overflow: hidden;'> de ".$res['autor']."</div>";
                }
            ?>
        </span>
            <div id="chat">

                <div id="campo-de-mensagem">
                    <?php          
                        $sql = "SELECT * FROM comentario WHERE obra = '$obra' AND ocultar = 0";
                        $res = $con->query($sql);
                        
                        if($res->num_rows > 0){
                            while($row = $res->fetch_assoc()){ 
                            
                                if($_SESSION['nome'] == $row['usuario']){   // minnha mensagem
                                    
                                    echo"<div class='my-message message'>
                                        <div><b>me:</b> <span>".$row['hora']."</span></div>
                                        <div style='display:flex;'>
                                        ".$row['comentario']." <a href='../php/apagarMessagem.php?t=2&l=".$row['id']."' style='background: gray;width:fit-content;padding:0;'><img src='../img/delete.png' style=' width: 15px;'/></a>
                                        </div>
                                    </div>";

                                }else{  // mensagem do outro
                                    
                                    echo"<div class='message'>
                                        <div><b>".$row['usuario']."</b> <span>".$row['hora']."</span></div>
                                        ".$row['comentario']."
                                    </div>";
                                }
                            }
                        }
                        $_SESSION['obra'] = $obra;
                    ?>
                </div>
                <form action="../php/comentar.php" method="post">
                    <input type="text" name="comentario" id="comentario" placeholder="Escreve o seu comentario ...">
                    <button type="submit">enviar </button>
                </form>  
            </div>
        </section>
    </main>
</div>
<script src="script.js"></script>
</body>
</html>