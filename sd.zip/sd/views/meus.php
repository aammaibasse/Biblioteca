<?php
session_start();
require_once'../php/_db.php';
if(!isset($_SESSION['id'])){    
    header('Location: ../index.php');
    die();   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/books.jpg" type="image/x-icon">
    <link rel="stylesheet" href="../css/home.css">
    <link rel="stylesheet" href="../css/section.css">
    <title>my Books</title>
</head>
<body> 
<div id="content">
    <header>
        <div><img src="../img/books.jpg" alt="logo" id="ll"></div>
        <h2>SD<i>Livraria</i></h2>
        <div></div>
    </header>
    <main>
        <aside>
            <div id="info">
                <?php
                    $foto = "../perfil/".$_SESSION['foto'];
                    echo"<img src='$foto'>";
                ?> 
                <h3><?php echo $_SESSION['nome']; ?></h3>
                <p><?php echo $_SESSION['email']; ?></p>
            </div>

            <div id="accao">
                <a href="./inserir.php">Inserir</a>
                <a href="./consultar.php">Consultar</a>
                <a href="./listar.php">Listar</a>
                <a class="active" href="./meus.php">My books</a>
                <a href="./chat.php">Chat</a>
            </div>
            <a href="../php/logout.php" id="bt-sair">
                <img src="../img/sair.svg" alt="sair">
            </a> 
        </aside>
        <section id="meusLivros">            
            <a href="./home.php" id="cancelar" >X</a>
            <div id="mybooks">
                <h2 style="width:100%; text-align:center;margin-bottom:20%;">Requisitados</h2>
                <?php
                    $id = $_SESSION['id'];
                    $sql = "SELECT * FROM recurso WHERE requitado = '$id'";      
                    $sql = $con->query($sql);
                    
                    while($r = $sql->fetch_assoc()){ 
                        $book = $r['livro'];
                        $capa = $r['capa'];
                        echo"
                            <div id='livro' >
                                <div id='img'>
                                <a href='./ler.php?l=".$book."' style=' background: transparent;'><img  src='../recurso/capa/$capa' alt='' style='flex: 2; width:105%; height: 120px;'></a>                                 
                                <div style='flex: 3; margin-left: 7px;'>
                                    <p>
                                        <b>".$r['titulo']." </b><br/>
                                        </b>Autor: </b> ".$r['autor']."<br/>
                                        <b>Língua: </b> ".$r['lingua']."<br/>
                                        <b>Ano: </b> ".$r['ano']."<br/>                                       
                                    </p>
                                </div>
                            </div>
                            <div id='links'>
                                <a href='../php/devolver.php?l=".$r['id']."'>Devolver</a>                               
                                <a href='./comentarios.php?l=".$r['id']."'>Comentários</a>
                            </div>
                            </div>
                        ";                     
                    }
                    if($sql->num_rows <= 0){
                        echo "<div class='sucess'>Nenhum livro Requisitado</div>";
                    }  
                ?>
            </div>


            <div id="reserva">
                <h2 style="width:100%; text-align:center;margin-bottom:20%;">Reservados</h2>
                <?php

                    $sql = "SELECT * FROM recurso WHERE reserva = '$id'";      
                    $sql = $con->query($sql);                    

                    while($r = $sql->fetch_assoc()){ 
                        $book = $r['livro'];
                        $capa = $r['capa'];
                        echo"
                            <div id='livro' >
                                <div id='img'>
                                <img  src='../recurso/capa/$capa' alt='' style='flex: 2; width:105%; height: 120px;>
                                <div style='flex: 3; margin-left: 7px;'>
                                    <p>
                                        <b>".$r['titulo']." </b><br/>
                                        </b>Autor: </b> ".$r['autor']."<br/>
                                        <b>Língua: </b> ".$r['lingua']."<br/>
                                        <b>Ano: </b> ".$r['ano']."<br/>                                       
                                    </p>
                                </div>
                            </div>
                            <div id='links'>
                                <a href='../php/cancelar.php?l=".$r['id']."'>Cancelar</a>                               
                                <a href='./comentarios.php?l=".$r['id']."'>Comentários</a>
                            </div>
                            </div>
                        ";                     
                    }
                    if($sql->num_rows <= 0){
                        echo "<div class='sucess'>Nenhum livro Reservado</div>";
                    } 
                

                ?>
            </div>
        </section>
    </main>
</div>
</body>
</html>