
<?php 
require_once'../php/_db.php';
session_start();
if(!isset($_SESSION['id']) OR $_SESSION['pos'] !="Admin"){
    header('Location:../index.php');
}
$id = $_GET['t'];

$sql = "DELETE FROM `usuario` WHERE id=".$id;
$con->query($sql);
header('Location:index.php');