<?php 
require_once'../php/_db.php';
session_start();
if(!isset($_SESSION['id']) OR $_SESSION['pos'] !="Admin"){
    header('Location:../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/books.jpg" type="image/x-icon">
    <link rel="stylesheet" href="../css/section.css">
    <link rel="stylesheet" href="admin.css">
    <title>Administracao > Remover usuario</title>
    <style>
       
        a{  width: 100px;border-radius: 5px;font-weight: bold; text-decoration:none; }
        a:hover{  }
        th, td{ padding: 5px;}
        fieldset{margin:5px;padding: 20px;}
        legend{padding:5px;}
        main, #aaa{    display: flex;    align-items: center;    justify-content: center;}
        .aaa{    display: block;    align-items: center;    justify-content: center;}
        #aaa:hover, .aaa:hover{box-shadow: 3px 3px 10px;}
        
    </style>
</head>
<body>
<div id="content">
    <header>
        <h2>SD<i>Livraria</i></h2>
        <div id="accao">
                <a href="./../php/logout.php">Terminar Sessao</a>
            </div>
    </header>
    <main>
        <div>
            <fieldset><legend>Confirmacao </legend>
            <?php
            $id = $_GET['t'];
            $sql = "SELECT id,nome FROM `usuario` WHERE `id`=".$id;
            $sql = $con->query($sql);
            $r = $sql->fetch_assoc();
            echo "
                <h3>Deseja realmente remover o usuario <span style='color:red;'>".$r['nome']."</span>
            
                <div style='display:flex; justify-content: space-between; padding:20px;'>
                    <a href='./delectarConta.php?t=".$r['id']."' style='background: purple;'>Remover</a>  
                    <a href='./index.php'>Cancelar</a>
                </div>              
            ";
            ?>
            </fieldset>
        </div>
    </main>
</div>
</body>
</html>