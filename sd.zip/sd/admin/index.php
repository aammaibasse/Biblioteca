<?php 
require_once'../php/_db.php';
session_start();
if(!isset($_SESSION['id']) OR $_SESSION['pos'] !="Admin"){
    header('Location:../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/books.jpg" type="image/x-icon">
    <link rel="stylesheet" href="../css/section.css">
    <link rel="stylesheet" href="admin.css">
    <title>Administracao</title>
    <style>
       
        a{  width: 100px;border-radius: 5px;font-weight: bold; text-decoration:none; }
        a:hover{  }
        th, td{ padding: 5px;}
        fieldset{margin:5px;padding: 5px;}
        legend{padding:5px;}
        #aaa,.a-links{    display: block;    align-items: center;    justify-content: center;}
        .aaa{    display: block;    align-items: center;    justify-content: center;}
        #aaa:hover, .aaa2:hover{box-shadow: 3px 3px 10px;}
        .a-links{display:flex; margin:5px;background-color:  rgba(43, 105, 188, 0.756);}
        
    </style>
</head>
<body>
<div id="content">
    <header>
        <h2>SD<i>Livraria</i></h2>
        <div style="display:flex;">
            <div style="display:flex;">
                <a href="#" class="a-links">Usuarios</a>
                <a href="#" class="a-links">Livros</a>
            </div>
            <div id="accao">
                <a href="./../php/logout.php">Terminar Sessao</a>
            </div>
        </div>
    </header>
    <main>
        <div>
            <fieldset><legend>Usuarios</legend>
            <?php
                $sql = "SELECT * FROM usuario";
                $sql = $con->query($sql);
                $i='00';
                ?>
                <table border="1">
                    <tr>
                        <th>Nr</th><th>Usuario</th><th>email</th><th>Requisicao</th><th>Reserva</th><th>Bloquear</th><th>Deletar</th>
                    </tr>
                <?php
                while($r = $sql->fetch_assoc()){                    
                    if($r['cargo'] != 'Admin'){
                        $i++;
                        $foto = "../perfil/".$r['foto'];
                        // echo "<div class='usuarios'>  $i -  ".$r['nome']." </div>";

                        echo "<tr>
                                <td>".$i."</td><td>".$r['nome']."</td><td>".$r['email']."</td>                                
                                <td>";

                                $lr = "SELECT * FROM recurso WHERE requitado = ".$r['id'];
                                $lr = $con->query($lr);

                                while($l = $lr->fetch_assoc()){
                                    echo $l['titulo']."<br/>";
                                }

                                echo "                                
                                </td>
                                <td>";

                                $lr = "SELECT * FROM recurso WHERE reserva = ".$r['id'];
                                $lr = $con->query($lr);

                                while($l = $lr->fetch_assoc()){
                                    echo $l['titulo']."<br/>";
                                }
                                echo "                                
                                </td>
                                <td id='aaa'>";
                                if($r['bloqueado']==1){
                                    echo "<a href='./desbloquear.php?t=".$r['id']."' style='background:green;'>Desbloquear</a>";
                                }else{
                                    echo "<a href='./bloquear.php?t=".$r['id']."' style='background: red;'>Bloquear</a>";
                                }
                                echo"
                                </td>

                                <td class='aaa2'>
                                    <a href='./confirmacao.php?t=".$r['id']."' style='background: purple;'>Remover</a>                               
                                </td>
                                
                            </tr>";
                    }                                        
                }
            ?> 
                </table>  
                      
            </fieldset>
        </div>

        </section>
        <!-- <aside>
            <div><h1>Lista de Livros</h1></div>
            <div id="livros">


            <!-- <?php
                    // $sql = "SELECT * FROM recurso"; 
                    // $sql = $con->query($sql);
                    // while($r = $sql->fetch_assoc()){ 
                    //     $book = $r['livro'];
                    //     $capa = $r['capa'];
                        
                    //     echo"
                    //         <div id='livro' >
                                
                                
                    //             <div style='flex: 1; margin-left: 7px;'>
                    //                 <p>
                    //                     <b>".$r['titulo']." </b><br/>
                    //                     </b>Autor: </b> ".$r['autor']."<br/>
                    //                     <b>Língua: </b> ".$r['lingua']."<br/>
                    //                     <b>Ano: </b> ".$r['ano']."<br/>
                    //                     ";

                    //                     if($r['estado'] == 'Disponível'){
                    //                         echo "<b style='color:green;'>".$r['estado']."</b>";
                    //                     }else{
                    //                         echo "<b style='color:red;'>".$r['estado']."</b>";
                    //                     }
                    //                     echo"                                        
                    //                 </p>
                    //             </div>
                    //         </div>
                    //         <div id='links'>
                    //             <a href='../php/deletar.php?l=".$r['id']."'>Excluir</a>
                    //         </div>
                    //     ";                             
                    // }
                ?> -->


            </div>
        </aside> -->
    </main>
</div>
</body>
</html>