<?php
session_start();
require_once'_db.php';
if(!isset($_SESSION['id'])){  
    echo"<script>alert('Fazer login...')</script>";
    header('Location: ../index.php');
    die();   
}

if(isset($_POST['btn'])){

    $user = $_SESSION['id'];
    $titulo = addslashes($_POST['titulo']);
    $autor = addslashes($_POST['autor']);
    $ano = addslashes($_POST['ano']);
    $lingua = addslashes($_POST['lingua']);
    
    if(isset($_FILES['ficheiro'])){

        // Carregar a capa do livro  (Opcional)
        if(!empty($_FILES['foto']['name'])){
            $ext = strtolower(substr($_FILES['foto']['name'],-4));
            
            if($ext =='.png' OR $ext == '.jpg' OR $ext == '.svg'){
                $capa = md5(time().$_FILES['foto']['name']);
                $dir = '../recurso/capa/';
                move_uploaded_file($_FILES['foto']['tmp_name'],$dir.$capa);
            
            }
        }else{            
            $capa = 'livro.jpg';
        }


        $ext = addslashes(strtolower(substr($_FILES['ficheiro']['name'],-4)));
        
        // Validacao de formato so para pdf
        if($ext != '.pdf'){
            $msg = "Formato invalido<br>So permitdo documentos pdf";
            $_SESSION['erro'] = $msg;
            header('Location:../views/inserir.php');
            die();
        }
        
        // Verificar se o recurso ja existe 
        $sql = "SELECT titulo, autor from recurso WHERE titulo = '$titulo' AND autor = '$autor'";
        $sql = $con->query($sql);

        if($sql->num_rows > 0){
            $msg = "Recurao ja cadastrado";
            $_SESSION['erro'] = $msg;
            header('Location:../views/inserir.php');
            die();
        }

        // Adcionar o ficheiro na pasta recurso        
        $ficheiro = $_FILES['ficheiro'];
        $livro = addslashes(strtolower($_FILES['ficheiro']['name']));
        $livro = md5(time()).$ext;
        $dir = '../recurso/';

        if(move_uploaded_file($ficheiro['tmp_name'],$dir.$livro)){
            
            $est = "Disponível";
            $sql = "INSERT INTO recurso (codEst,livro,titulo,capa,lingua,autor,ano,estado) VALUES ('$user','$livro','$titulo','$capa','$lingua','$autor','$ano','$est')";
    
            $sql = $con->query($sql);
            $_SESSION['erro'] = "Ficheiro Particlho com sucesso!";  
            header('Location:../views/inserir.php');
            exit();
        }
    }else{
        echo "<script>alert('Selecione um ficheiro para partilhar')</script>";
        header('Location:../views/inserir.php');
        die();        
    }

}
$_SESSION['erro'] = "<i>Preencha todos os campos!</i>";
header('Location:../views/inserir.php');
die();