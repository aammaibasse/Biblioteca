<?php
session_start();
require_once'_db.php';
if(!isset($_SESSION['id'])){  
    echo"<script>alert('Fazer login...')</script>";
    header('Location: ../index.php');
    die();   
}
$obra = $_GET['l'];
$id = $_SESSION['id'];

$sql = "SELECT * FROM usuario WHERE id='$id'";
$sql = $con->query($sql);
$r = $sql->fetch_assoc();

$sql = "UPDATE `recurso` SET `estado`='Disponível', `requitado`='0' WHERE  id=".$obra;
switch ($obra) {
    case $r['livro1']:$user = "UPDATE `usuario` SET `livro1`= '0' WHERE  id= '$id'"; break;
    case $r['livro2']:$user = "UPDATE `usuario` SET `livro2`= '0' WHERE  id= '$id'"; break;
    case $r['livro3']:$user = "UPDATE `usuario` SET `livro3`= '0' WHERE  id= '$id'"; break;
}


if($sql = $con->query($sql) AND $user = $con->query($user) ){

    // Entregar na reserva
    $sql = "SELECT reserva FROM recurso";
    $sql = $sql = $con->query($sql);
    $sql = $sql->fetch_assoc();
    $sql = $sql['reserva'];
    
    if($sql != 0){
        $sql = "UPDATE `recurso` SET `requitado`='$sql',`reserva`='0' WHERE id='$obra'";
        $sql = $sql = $con->query($sql);
    }

    $msg = "Arquivo Devolvido com sucesso!<br/>";
    $_SESSION['sucess'] = $msg;
    header('Location:../views/meus.php');
    exit();
}


$_SESSION['erro'] = $msg;
header('Location:../views/home.php');
exit();
