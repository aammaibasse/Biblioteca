<?php
$con = mysqli_connect("localhost","root","","sd");
if(!$con){
    die("Conecxao falhou....");
}

?>
