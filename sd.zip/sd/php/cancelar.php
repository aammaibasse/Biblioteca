<?php
session_start();
require_once'_db.php';
if(!isset($_SESSION['id'])){  
    echo"<script>alert('Fazer login...')</script>";
    header('Location: ../index.php');
    die();   
}

$id = $_GET['l'];
$sql = "UPDATE `recurso` SET `reserva`='0' WHERE id='$id'";
$sql = $sql = $con->query($sql);
header('Location:../views/meus.php');
exit();