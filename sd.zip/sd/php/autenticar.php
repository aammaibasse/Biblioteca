<?php
require_once'_db.php';

if(isset($_POST['email']) AND isset($_POST['senha'])){
    $email = addslashes($_POST['email']);
    $senha = md5(addslashes($_POST['senha']));

    $sql = "SELECT * FROM usuario WHERE email = '$email' AND senha = '$senha'";
    $sql = $con->query($sql);
    
    if(!$i = $sql->fetch_assoc()){
        $msg = "Email/Senha Incorrecta!";
        $_SESSION['erro'] = $msg;
        header("Location:../index.php?e=$msg");
        exit();
    }else{

        if($i['bloqueado'] == 1){
            $msg = "usuario bloqueado pelo administrador!";
            $_SESSION['erro'] = $msg;
            header("Location:../index.php?e=$msg");
            exit();
        }
        session_start();
        $_SESSION['id'] = $i['id'];
        $_SESSION['nome'] = $i['nome'];
        $_SESSION['email'] = $i['email'];
        $_SESSION['foto'] = $i['foto'];
        $_SESSION['pos'] = $i['cargo'];
        $_SESSION['obra']= false;
        $_SESSION['erro']= false;
        $_SESSION['sucess']= false;
        $_SESSION['livro1']= false;
        $_SESSION['livro2']= false;
        $_SESSION['livro3']= false;

        if($_SESSION['pos'] == 'Admin'){
            header('Location:../admin/index.php');
            exit();
        }
        header("Location:../views/home.php");      
    }
}else{
    header("Location:../index.php");
}