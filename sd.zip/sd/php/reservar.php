<?php
session_start();
require_once'_db.php';
if(!isset($_SESSION['id'])){  
    echo"<script>alert('Fazer login...')</script>";
    header('Location: ../index.php');
    die();   
}

$id = $_GET['l'];
$u = $_SESSION['id'];

$sql = "SELECT reserva FROM recurso";
$sql = $sql = $con->query($sql);
$sql = $sql->fetch_assoc();
$sql = $sql['reserva'];

if($sql == 0){

    $sql = "UPDATE `recurso` SET `reserva`='$u' WHERE id='$id'";
    if($sql = $con->query($sql)){
        $_SESSION['sucess'] = "Reserva Efectuada!";
        header('Location:../views/meus.php');
    }else{
        $_SESSION['sucess'] = "Reserva nao realizada!";
        header('Location:../views/home.php');
    }
    
}else{
    echo "livro ja reservado!";
}
exit();
