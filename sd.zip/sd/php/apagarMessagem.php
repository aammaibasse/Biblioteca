<?php
session_start();
require_once'_db.php';
if(!isset($_SESSION['id'])){  
    echo"<script>alert('Fazer login...')</script>";
    header('Location: ../index.php');
    die();   
}
$t = ($_GET['t']==1)?'chat':'comentario';
$id = $_GET['l'];

$sql = "UPDATE ".$t." SET `ocultar`='1' WHERE `id`=".$id;

if($sql = $con->query($sql)){
    $t = ($t=='comentario')?'comentarios':'chat';
    header('Location:../views/'.$t.'.php');    
    exit();
}
die('Messagem ja apagada,<br> faz um refresh na pagina!');
