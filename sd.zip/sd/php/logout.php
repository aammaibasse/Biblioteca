<?php
session_start();
session_unset();
session_cache_expire();
session_destroy();
header("Location:../index.php");