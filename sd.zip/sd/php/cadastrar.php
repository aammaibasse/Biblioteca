<?php
session_start();
require_once'_db.php';

if(isset($_POST['btn'])){
   
    if(!empty($_POST['nome']) AND !empty($_POST['email']) AND !empty($_POST['senha']) AND !empty($_POST['csenha'])){
        
        $nome = addslashes($_POST['nome']);
        $email = addslashes($_POST['email']);    
        $senha = md5(addslashes($_POST['senha']));   
        $csenha = md5(addslashes($_POST['csenha']));
        $perfil = ""; 

        if($senha === $csenha){
            
            if(!empty($_FILES['foto']['name'])){
                $ext = strtolower(substr($_FILES['foto']['name'],-4));
                
                if($ext =='.png' OR $ext == '.jpg' OR $ext == '.svg'){
                    $perfil = md5(time().$_FILES['foto']['name']);
                    $dir = '../perfil/';
                    move_uploaded_file($_FILES['foto']['tmp_name'],$dir.$perfil);
                
                }else{
                    $msg = "Foto de formato invalido!";
                    header("Location: ../views/cadastro.php?e=$msg");
                    exit();
                }
            }else{            
                $perfil = 'user.svg';
            }

            // die();
            $sql = "SELECT * FROM usuario WHERE email='$email'";
            $sql = $con->query($sql);

            if($sql->num_rows > 0){
                $msg = "Email ja cadastrado";
                header("Location: ../views/cadastro.php?e=$msg");
                exit();

            }else{
                $sql = "INSERT INTO usuario (nome,email,senha,foto) VALUES ('$nome','$email','$senha','$perfil')"; 
                $sql = $con->query($sql);
                $msg = "Cadastrado com sucesso";
                echo "<script>alert($msg)</script>";
            }
        }else{
            $msg = "Senhas diferentes";
            header("Location: ../views/cadastro.php?e=$msg");   
        }
    }else{
        $msg = "Preencha todos os campos";
        header("Location: ../views/cadastro.php?e=$msg");   
    }
}
header('Location: ../index.php'); 