<?php
session_start();
require_once'_db.php';
if(!isset($_SESSION['id'])){  
    echo"<script>alert('Fazer login...')</script>";
    header('Location: ../index.php');
    die();   
}

if(isset($_POST['mensagem']) AND !empty($_POST['mensagem'])){
    $mensagem = addslashes($_POST['mensagem']);
    $user = $_SESSION['nome'];

    $sql = "INSERT INTO chat (usuario,mensagem,hora) VALUES ('$user','$mensagem',NOW())";
    $sql = $con->query($sql);
    header("Location: ../views/chat.php");
}
header("Location: ../views/chat.php");
?>
