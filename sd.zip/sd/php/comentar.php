<?php
session_start();
require_once'_db.php';
if(!isset($_SESSION['id'])){  
    header('Location: ../index.php');
    die();   
}

if(isset($_POST['comentario']) AND !empty($_POST['comentario'])){
    $comentario = addslashes($_POST['comentario']);
    $user = $_SESSION['nome'];
    $obra = $_SESSION['obra']; 

    $sql = "INSERT INTO comentario (usuario,comentario,obra,hora) VALUES ('$user','$comentario','$obra',NOW())";
    $sql = $con->query($sql);
}
header("Location: ../views/comentarios.php?l=".$obra."");
?>