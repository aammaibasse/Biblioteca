<?php
session_start();
require_once'_db.php';
if(!isset($_SESSION['id'])){  
    echo"<script>alert('Fazer login...')</script>";
    header('Location: ../index.php');
    die();   
}


$sql = "SELECT * FROM usuario WHERE id=".$_SESSION['id'];
$user = $con->query($sql);
$user = $user->fetch_assoc();

if($user['livro1'] != 0 AND $user['livro2'] != 0 AND $user['livro3'] != 0){
    $_SESSION['erro'] = "Desculpe<br/>Nao pode requistar mais livros<br>Atinjiu o limite de livros a requisitar";
    header('Location:../views/meus.php');
    exit();
}
$obra = $_GET['l'];
$id = $_SESSION['id'];

if($user['livro1'] == 0){
    $user = "UPDATE `usuario` SET `livro1`='$obra' WHERE id='$id'"; 
}else{
    if($user['livro2'] == 0){
        $user = $user = "UPDATE `usuario` SET `livro2`='$obra' WHERE id='$id'";
    }else{
        if($user['livro3'] == 0){
            $user = $user = "UPDATE `usuario` SET `livro3`='$obra' WHERE id='$id'";
        }          
    }
}

$sql = "UPDATE `recurso` SET `estado`='Indisponível',`requitado`='$id' WHERE id=".$obra;
 
$sql = $con->query($sql);
$user = $con->query($user);

$msg = "Arquivo requisitado com sucesso!<br/>Boa leitura";
$_SESSION['sucess'] = $msg;
header('Location:../views/meus.php');
exit();
