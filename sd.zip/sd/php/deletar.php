<?php
session_start();
require_once'_db.php';
if(!isset($_SESSION['id'])){  
    echo"<script>alert('Fazer login...')</script>";
    header('Location: ../index.php');
    die();   
}
$obra = $_GET['l'];
$sql = "DELETE FROM `recurso` WHERE id=".$obra;
if($sql = $con->query($sql)){
    $msg = "Arquivo delectado com sucesso!";
    $_SESSION['sucess'] = $msg;
    header('Location:../views/partilhado.php');
    exit();
}

$msg = "Arquivo não delectado";
$_SESSION['erro'] = $msg;
header('Location:../views/partilhado.php');
exit();
